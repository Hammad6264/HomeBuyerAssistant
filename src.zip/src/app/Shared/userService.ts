import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class UserService {
    constructor() {
        // TODO
    }
    set(userFromDatabase) {
        localStorage.setItem('user', JSON.stringify(userFromDatabase));
    }
    get() {
        return localStorage.getItem('user');
    }
}
