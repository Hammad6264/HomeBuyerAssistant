import * as firebase from 'firebase';
import { Injectable } from '@angular/core';
import {AlertController, LoadingController} from '@ionic/angular';
import {UserService} from './userService';
import {CommonServices} from './CommonService';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

  constructor(private commonServices: CommonServices, private alertCtrl: AlertController, private loadCtrl: LoadingController, private userService: UserService) {}

  signupUser(gmail: string, pass: string, userName: string, mobileNumber: number, languages: string, flagOfLanguages: string) {
      this.loadCtrl.create({
          message: 'Please wait...',
          spinner: 'lines'
      }).then((loadingEl) => {
          loadingEl.present();
          firebase.auth().createUserWithEmailAndPassword(gmail, pass).then((userData) => {
              console.log(userData);
              const user = firebase.auth().currentUser;
              user.sendEmailVerification();
              firebase.database().ref('users/' + userData.user.uid).set({
                  id: userData.user.uid,
                  name: userName,
                  email: gmail,
                  phone: mobileNumber,
                  password: pass,
                  language: languages,
                  flag: flagOfLanguages,
                  registerationDate: new Date().toString(),
              }).then(() => {
                  firebase.auth().signOut();
                  loadingEl.dismiss();
                  this.alertCtrl.create({
                      header: 'Account Succesfully Created!',
                      // tslint:disable-next-line:max-line-length
                      message: 'Thanks for creating your account! your account has been successfully created. Please check your email to verify your account, and then please Login to proceed. Thanks!',
                      buttons: [{
                          text: 'Okay!',
                          handler: () => {
                              alert('Please check your email to verify');
                              this.commonServices.navigate('/login');
                          }
                      }]
                  }).then((elementEl) => {
                      elementEl.present();
                  });
              });
          }, (err) => {
              loadingEl.dismiss();
              this.alertCtrl.create({
                  header: err.code,
                  message: err.message,
                  buttons: [{
                      text: 'Okay!',
                      role: 'dismiss'
                  }]
              }).then((elementEl) => {
                  elementEl.present();
              });
          });
      });
  }
  getUserFromDatabase(uid) {
        const ref = firebase.database().ref('users/' + uid);
        return ref.once('value').then(snapshot => snapshot.val());
    }
    set(lng) {
        localStorage.setItem('user', JSON.stringify(lng));
      }
  signinUser(email: string, password: string) {
    this.loadCtrl.create({
          message: 'Please wait...',
          spinner: 'lines'
     }).then((loadingEl) => {
          loadingEl.present();
          firebase.auth().signInWithEmailAndPassword(email, password)
            .then((response) => {
                console.log(response);
                if (response.user.emailVerified) {
                    loadingEl.dismiss();
                    this.set(response.user.uid);
                    this.commonServices.navigate('/step-guide');
                    this.alertCtrl.create({
                        header: 'Account Succesfully Logged In!',
                        message: 'Welcome back! you have been successfully logged in. Thanks!',
                        buttons: [{
                            text: 'Okay!',
                            handler: () => {
                                this.commonServices.navigate('/step-guide');
                            }
                        }]
                    }).then((getAlert) => {
                        getAlert.present();
                    });
                    return this.getUserFromDatabase(response.user.uid);
                } else {
                    firebase.auth().currentUser.sendEmailVerification();
                    firebase.auth().signOut();
                    loadingEl.dismiss();
                    this.alertCtrl.create({
                        header: 'Email Not Verified!',
                        message: 'Your email is not verify yet. Please check your email and verify it!',
                        buttons: [{
                            text: 'Okay!',
                            handler: () => {
                                this.commonServices.navigate('/login');
                            }
                        }]
                    }).then((elementEl) => {
                        elementEl.present();
                    });
                }
            }, (err) => {
                loadingEl.dismiss();
                this.alertCtrl.create({
                    header: 'Error in Logging Your Account!',
                    subHeader: err.code,
                    message: err.message,
                    buttons: [{
                        text: 'Okay!',
                        role: 'dismiss'
                    }]
                }).then((elementEl) => {
                    elementEl.present();
                });
            }).then((data) => {
            if (data) {
                this.userService.set(data);
                console.log(data);
            } else {
                console.log('Bad Luck!');
            }
        });
    });
  }

  logout() {
    localStorage.clear();
    firebase.auth().signOut();
    this.commonServices.navigate('/login');
  }
  resetPassword(email: string) {
        this.loadCtrl.create({
            message: 'Please wait...'
        }).then((loadingEl) => {
            loadingEl.present();
            const auth = firebase.auth();
            return auth.sendPasswordResetEmail(email).then(() => {
                this.commonServices.navigate('/login');
                loadingEl.dismiss();
                this.alertCtrl.create({
                    header: 'Email has been sent!',
                    message: 'Reset verification email has been sent to your email, please check!',
                    buttons: [{
                        text: 'Okay!',
                        role: 'dismiss'
                    }]
                }).then((elementEl) => {
                    elementEl.present();
                });
            }, (err) => {
                loadingEl.dismiss();
                this.alertCtrl.create({
                    header: err.code,
                    message: err.message,
                    buttons: [{
                        text: 'Okay!',
                        role: 'dismiss'
                    }]
                }).then((elementEl) => {
                    elementEl.present();
                });
            });
        });
    }
}
// 5 views = 1hour
// needed hours = 4000
// total hour = 53

