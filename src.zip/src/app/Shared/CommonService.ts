import {Injectable} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ActionSheetController, AlertController, LoadingController, ToastController} from '@ionic/angular';

/*
     fetchSingleValue(getData) {
         this.route.params.subscribe(params => {
            return getData = params['value'];
         });
     }
     fetchWholeValue(getData) {
         this.route.queryParams.subscribe((res) => {
             return getData = JSON.parse(res.value);
         });
     }

*/
@Injectable({
    providedIn: 'root'
})
export class CommonServices {
     constructor(public router: Router, public alertCtrl: AlertController, public actionSheetCtrl: ActionSheetController, public loadCtrl: LoadingController, public toastCtrl: ToastController) {}
     navigate(page) {
        return this.router.navigate([page]);
     }
     navigateByWholeValue(page, value) {
        return this.router.navigate([page], {
             queryParams: {
                 value: JSON.stringify(value)
             }
         });
     }
     navigateBySingleValue(page, SingleValue) {
         return this.router.navigate([page, { value: SingleValue }]);
     }
    async presentAlert(title: string, content: string) {
        const alert = await this.alertCtrl.create({
            header: title,
            message: content,
            buttons: ['OK']
        });
        await alert.present();
    }
   loadAlert(content: string) {
       return this.loadCtrl.create({
            message: content
        }).then((elementEl) => {
            elementEl.present();
            setTimeout(() => {
               elementEl.dismiss();
            }, 2000);
        });
    }
   async toastAlert(content: string, time: number) {
        const alert = await this.toastCtrl.create({
            message: content,
            duration: time
        });
        await alert.present();
    }
    refreshPage()  {
         window.location.reload();
    }
     async presentActionSheet() {
        const actionSheet = await this.actionSheetCtrl.create({
            header: 'Albums',
            buttons: [{
                text: 'Delete',
                role: 'destructive',
                icon: 'trash',
                handler: () => {
                    console.log('Delete clicked');
                }
            }, {
                text: 'Share',
                icon: 'share',
                handler: () => {
                    console.log('Share clicked');
                }
            }]
        });
        await actionSheet.present();
    }
}
