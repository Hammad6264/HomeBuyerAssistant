import { Component } from '@angular/core';
import {CommonServices} from '../../../Shared/CommonService';
import {UserService} from '../../../Shared/userService';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
})
export class WelcomePage {
  lng: string;
  lngE = '" English "';
  lngS = '" Esponol "';
  switchBtnText: string;
  isTxtVideo = false;

  constructor(public commonService: CommonServices, private userService: UserService) {
  }

  onStart() {
    this.someWhatSet(true);
    const isStartNow = this.someWhatGet();
    console.log(isStartNow);
    const isLogin = this.get();
    if (isLogin) {
      this.commonService.navigate('/step-guide');
    } else {
      this.commonService.navigate('/login');
    }
  }
  someWhatSet(lng) {
    localStorage.setItem('started', JSON.stringify(lng));
  }
  get() {
    return localStorage.getItem('user');
}
  someWhatGet() {
  return localStorage.getItem('started');
}
  onToggleSwitch() {
    if (this.isTxtVideo) {
      this.isTxtVideo = false;
      this.switchBtnText = this.lng === this.lngE ? 'Switch To Text' : 'CAMBIAR A TEXTO';
    } else {
      this.isTxtVideo = true;
      this.switchBtnText = this.lng === this.lngE ? 'Switch To Video' : 'Cambiar a video';
    }
  }
  ionViewWillEnter() {
    const myLanguage = localStorage.getItem('lng');
    this.lng = myLanguage;
    console.log(this.lng);
    if (this.lng === this.lngE) {
      this.switchBtnText = 'Switch To Text';
    } else {
      this.switchBtnText = 'Cambiar a texto';
    }
    const isStarted = localStorage.getItem('started');
    const isLogin = this.userService.get();
    console.log(isStarted, isLogin);
    if (isStarted) {
      if (isLogin) {
        this.commonService.navigate('/step-guide');
      } else {
        this.commonService.navigate('/login');
      }
    } else {
      console.log('Nothing TODO');
    }
  }
}
