import {Component, ViewChild} from '@angular/core';
import {AngularFireDatabase, AngularFireList} from '@angular/fire/database';
import {Chat} from '../../../models/chat';
import {User} from '../../../models/user';
import {HttpClient} from '@angular/common/http';
import {ChatsService} from '../../../services/chats/chats.service';
import {UtilService} from '../../../services/util/util.service';
import {CommonServices} from '../../../Shared/CommonService';
import {AuthService} from '../../../services/auth/auth.service';
import {LoadingController} from '@ionic/angular';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.page.html',
  styleUrls: ['./questions.page.scss'],
})
export class QuestionsPage {
  message: string;
  uid = '';
  interlocutorUID  = '';
  chats: Array<Chat>;
  chatsRef: AngularFireList<Chat>;
  uidData: User;
  interlocutorUIDData: User;
  imgData: any;
  imgURL: any;
  key = 'f984c7ecc6504e4e9252a39e112daa7e';
  @ViewChild('fileButton', { static: false }) fileButton;
  status: any;
  constructor(
      private chatsService: ChatsService,
      private db: AngularFireDatabase,
      private utilService: UtilService,
      private httpClient: HttpClient,
      private commonService: CommonServices,
      private auth: AuthService,
      private loadCtrl: LoadingController
  ) {
    this.loadCtrl.create({
      message: 'Please wait while loading questions',
      spinner: 'lines'
    }).then(elementEl => {
      elementEl.present();
      setTimeout(() => {
        const objDiv = document.getElementById('toScroll');
        objDiv.scrollTop = objDiv.scrollHeight;
      }, 1000);
      this.uid  = this.auth.getCurrentUserUid();
      this.interlocutorUID =  this.chatsService.chatter.interlocutorUID;
      console.log(this.interlocutorUID);
      const presence = this.auth.getPresence(this.interlocutorUID);
      presence.subscribe(data => {
        console.log(data);
        this.status = data['status'];
        console.log(this.status);
      });
      console.log(this.uid, this.interlocutorUIDData);
      chatsService.getChatRef(this.uid, this.interlocutorUID).then((chatRefPath: string) => {
        console.log('chatRef: uid, interlocutorUID', chatRefPath);
        this.chatsRef = this.db.list(chatRefPath);
        this.db.list(chatRefPath).valueChanges().subscribe((chats: Chat[]) => { console.log('chats', chats);  this.chats = chats; const objDiv = document.getElementById('toScroll');
                                                                                objDiv.scrollTop = objDiv.scrollHeight; }) ;
      });
      // tslint:disable-next-line:max-line-length
      this.db.object(`/users/${this.uid}`).valueChanges().subscribe((user: User) => { console.log('loged user', user); this.uidData = user; });
      // tslint:disable-next-line:max-line-length
      this.db.object(`/users/${this.interlocutorUID}`).valueChanges().subscribe((user: User) => { console.log('interlo', user);  this.interlocutorUIDData = user; elementEl.dismiss(); });
    });
  }
  sendMessage(): void {
    if (this.message) {
      const chat: Chat = {
        from: this.uid,
        message : this.message,
        type: 'message',
        to: this.interlocutorUID,
        picture : null
      };
      this.chatsRef.push(chat);
      this.message = '';
      const objDiv = document.getElementById('toScroll');
      objDiv.scrollTop = objDiv.scrollHeight;
    }
  }
  sendPicture(): void {
     this.fileButton.nativeElement.click();
  }
  fileChanged(event) {
    const files = event.target.files;
    console.log(files);
    this.imgData = event.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      this.imgURL = reader.result;
      const form = new FormData();
      form.append('image', this.imgData);
      this.httpClient.post('https://api.imgbb.com/1/upload?key=' + this.key, form).subscribe(res => {
        console.log(res);
        if (res['status'] === 200) {
          this.imgURL = res['data'].display_url;
          const chat: Chat  = {
            from: this.uid,
            message: '',
            type: 'picture',
            picture: this.imgURL,
            to: this.interlocutorUID,
          };
          this.chatsRef.push(chat);
        }
      }, (err) => {
        if (err) {
          this.commonService.presentAlert('err: ' + err['error'].error.code, err['error'].error.message);
        }
      });
    };
    reader.readAsDataURL(event.target.files[0]);
  }
}
