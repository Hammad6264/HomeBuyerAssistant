import { Component, OnInit } from '@angular/core';
import {CommonServices} from '../../../Shared/CommonService';
import {UserService} from '../../../Shared/userService';

@Component({
  selector: 'app-languages',
  templateUrl: './languages.page.html',
  styleUrls: ['./languages.page.scss'],
})
export class LanguagesPage  {
  isActiveButton = false;
  setLanguage: string;
  btnTxt = 'Accept';
  isStart = false;
  constructor(private commonService: CommonServices, private userService: UserService) {
    this.isStart = false;
    const isStarted = localStorage.getItem('started');
    const isLogin = this.userService.get();
    console.log(isStarted, isLogin);
    setTimeout(() => {
        if (isStarted) {
            this.isStart = false;
            if (isLogin) {
                this.commonService.navigate('/step-guide');
            } else {
                this.commonService.navigate('/login');
                this.isStart = true;
            }
        } else {
            this.isStart = true;
        }
    }, 2000);
  }
  ionViewWillEnter() {
     this.isStart = false;
     setTimeout(() => {
        this.isStart = true;
      }, 2000);
  }
  setClass(label: string) {
     if (label === 'label1') {
         document.getElementById(label).classList.add('active');
         document.getElementById('label2').classList.remove('active');
         this.setLanguage = '';
         this.setLanguage = document.getElementById(label).innerHTML;
         this.isActiveButton = true;
         this.btnTxt = 'Accept';
     } else if (label === 'label2') {
         document.getElementById(label).classList.add('active');
         document.getElementById('label1').classList.remove('active');
         this.setLanguage = '';
         this.setLanguage = document.getElementById(label).innerHTML;
         this.isActiveButton = true;
         this.btnTxt = 'Aceptar';
     }
  }
    set(lng) {
        localStorage.setItem('lng', JSON.stringify(lng));
    }
    get() {
        return localStorage.getItem('lng');
    }
    someWhatSet(lng) {
        localStorage.setItem('started', JSON.stringify(lng));
      }
    onSave(key: string) {
        console.log(key);
        const lng = this.get();
        if (lng) {
            this.isStart = false;
            this.set(key);
            const isStarted = localStorage.getItem('started');
            const isLogin = this.userService.get();
            console.log(isStarted, isLogin);
            setTimeout(() => {
                if (isStarted) {
                  //  localStorage.clear();
                    if (isLogin) {
                        this.someWhatSet(true);
                        this.commonService.navigate('/step-guide');
                        this.isStart = true;
                    } else {
                        this.someWhatSet(true);
                        this.commonService.navigate('/login');
                        this.isStart = true;
                    }
                } else {
                    this.isStart = true;
                    this.commonService.navigate('/welcome');
                }
            }, 2000);
        } else {
            this.set(key);
            this.commonService.navigate('/welcome');
        }
    }
}
