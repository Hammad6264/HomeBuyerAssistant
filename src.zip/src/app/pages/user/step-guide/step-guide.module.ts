import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StepGuidePageRoutingModule } from './step-guide-routing.module';

import { StepGuidePage } from './step-guide.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    StepGuidePageRoutingModule
  ],
  declarations: [StepGuidePage]
})
export class StepGuidePageModule {}
