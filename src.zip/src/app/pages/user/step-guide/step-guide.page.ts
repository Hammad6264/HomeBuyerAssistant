import { Component } from '@angular/core';
import {CommonServices} from '../../../Shared/CommonService';
import {UserService} from '../../../Shared/userService';
import {ChatsService} from '../../../services/chats/chats.service';
import {AuthService} from '../../../Shared/AuthService';
import * as firebase from 'firebase';

@Component({
  selector: 'app-step-guide',
  templateUrl: './step-guide.page.html',
  styleUrls: ['./step-guide.page.scss'],
})
export class StepGuidePage {
  pageName = '';
  lng: string;
  lngE = '" English "';
  lngS = '" Esponol "';
  id: any;
  isUser = false;
  constructor(
      public commonService: CommonServices,
      private userService: UserService,
      private chatsService: ChatsService,
      private auth: AuthService
  ) {
  }
  ionViewWillEnter() {
    const myLanguage = localStorage.getItem('lng');
    this.lng = myLanguage;
    const isLogin = JSON.parse(this.userService.get());
    if (isLogin !== null) {
      this.id = isLogin.id;
      console.log(this.id);
      this.isUser = true;
    } else {
      this.isUser = false;
    }
    setTimeout(() => {
      if (isLogin !== null) {
        const isLogi = JSON.parse(this.userService.get());
        this.id = isLogi.id;
        console.log(this.id);
        this.isUser = true;
      } else {
        this.isUser = false;
      }
    }, 2000);
  }
  onLogout() {
    firebase.auth().signOut();
    localStorage.clear();
    this.commonService.presentAlert('', 'You have been successfully logout!');
    this.commonService.navigate('/login');
  }
  onMakeQuestion() {
    const isLogin = JSON.parse(this.userService.get());
    console.log(isLogin);
    if (isLogin === null) {
      this.commonService.presentAlert('Login is Required', 'In order to make a question, you must have to be log in fisrt!');
      this.commonService.navigate('/register');
    }
    if (isLogin) {
      if (isLogin.id === '1PwgUiJ8qpTAoCkR7ER2zXrV7y52') {
        this.commonService.navigate('/chats');
      } else {
        this.chatsService.chatter =  {
          uid : isLogin.id,
          interlocutorUID : '1PwgUiJ8qpTAoCkR7ER2zXrV7y52'
        };
        this.commonService.navigate('/questions');
      }
    }
  }
}
