import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { StepGuidePage } from './step-guide.page';

describe('StepGuidePage', () => {
  let component: StepGuidePage;
  let fixture: ComponentFixture<StepGuidePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepGuidePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(StepGuidePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
