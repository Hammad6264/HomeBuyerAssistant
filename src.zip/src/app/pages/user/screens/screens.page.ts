import { Component } from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-screens',
  templateUrl: './screens.page.html',
  styleUrls: ['./screens.page.scss'],
})
export class ScreensPage {
  pageName = '';
  lng: string;
  lngE = '" English "';
  lngS = '" Esponol "';
  switchBtnText: string;
  isTxtVideo = false;
  isInfo: boolean;
  constructor(private route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.pageName = params['value'];
      if (this.pageName === 'advantage') {
          this.isInfo = true;
      } else if (this.pageName === 'who') {
          this.isInfo = true;
      } else if (this.pageName === 'first') {
        this.isInfo = true;
      } else {
         this.isInfo = false;
      }
    });
  }

  ionViewWillEnter() {
    const myLanguage = localStorage.getItem('lng');
    this.lng = myLanguage;
    if (this.lng === this.lngE) {
      this.switchBtnText = 'Swicth To Text';
    } else {
      this.switchBtnText = 'Cambiar a texto';
    }
  }
  onToggleSwitch() {
    if (this.isTxtVideo) {
      this.isTxtVideo = false;
      this.switchBtnText = this.lng === this.lngE ? 'Switch To Text' : 'CAMBIAR A TEXTO';
    } else {
      this.isTxtVideo = true;
      this.switchBtnText = this.lng === this.lngE ? 'Switch To Video' : 'Cambiar a video';
    }
  }
}
