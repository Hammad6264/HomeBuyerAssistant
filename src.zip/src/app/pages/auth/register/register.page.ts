import { Component } from '@angular/core';
import {CommonServices} from '../../../Shared/CommonService';
import {NgForm} from '@angular/forms';
import {AuthService} from '../../../Shared/AuthService';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage {
  isButn = false;
  imgPATH: string;
  lng: string;
  lngE = '" English "';
  lngS = '" Esponol "';
  eyeiconOne = 'fas fa-eye';
  eyeiconTwo = 'fas fa-eye';
  country = '92';
  constructor(public commonService: CommonServices, private authService: AuthService) {
     if (this.lng === this.lngE) {
       this.isButn = true;
       this.imgPATH = '/assets/USA.jpg';
     } else {
       this.isButn = true;
       this.imgPATH = '/assets/Spain.jpg';
     }
  }
  set(lng) {
    localStorage.setItem('lng', JSON.stringify(lng));
  }
  getValue(id: string, flag: string) {
     document.getElementById('butn').innerHTML = document.getElementById(id).innerHTML;
     this.imgPATH = flag;
     this.isButn = true;
  }
  onRegister(form: NgForm) {
    const userName = form.value.name;
    const userEmail = form.value.email;
    const userPhone = Number(this.country) + form.value.phone;
    const countryCode = this.country;
    const userPassword = form.value.passwords;
    const userConfirmPassword = form.value.confirms;
    const languages = document.getElementById('butn').innerHTML;
    const flag = this.imgPATH;
    console.log({
      userEmail, userPassword, userName, userPhone, languages, flag
    });
    // tslint:disable-next-line:max-line-length
    if (userName === '' || userEmail === '' || userPassword === '' || userConfirmPassword === '' || userPhone === '' || countryCode === '') {
      this.commonService.presentAlert('Something is missing', 'It\' looks like that something is missing, please check');
    } else {
      if (userPassword === userConfirmPassword) {
        this.authService.signupUser(userEmail, userPassword, userName, userPhone, languages, flag);
        form.reset();
      } else {
        this.commonService.presentAlert('Password do not match', 'Please check your password');
      }
    }
  }

  ionViewWillEnter() {
    const myLanguage = localStorage.getItem('lng');
    this.lng = myLanguage;
  }
  togglePasswordOne() {
    const x = (document.getElementById('pwd') as HTMLInputElement);
    console.log(x);
    if (x.type === 'password') {
      x.type = 'text';
      this.eyeiconOne = 'fas fa-eye-slash';
    } else {
      x.type = 'password';
      this.eyeiconOne = 'fas fa-eye';
    }
  }
  togglePasswordTwo() {
    const x = (document.getElementById('ppwd') as HTMLInputElement);
    if (x.type === 'password') {
      x.type = 'text';
      this.eyeiconTwo = 'fas fa-eye-slash';
    } else {
      x.type = 'password';
      this.eyeiconTwo = 'fas fa-eye';
    }
  }
}
