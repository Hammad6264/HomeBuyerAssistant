import { Component } from '@angular/core';
import {NgForm} from '@angular/forms';
import {AuthService} from '../../../Shared/AuthService';
import {CommonServices} from '../../../Shared/CommonService';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  lng: string;
  lngE = '" English "';
  lngS = '" Esponol "';
  eyeicon = 'fas fa-eye';
  constructor(private authService: AuthService, public commonService: CommonServices) { }

  onLogin(form: NgForm) {
    const email = form.value.email;
    const password = form.value.passwords;
    console.log(email, password);
    this.authService.signinUser(email, password);
    form.reset();
  }
  ionViewWillEnter() {
    const myLanguage = localStorage.getItem('lng');
    this.lng = myLanguage;
  }
  togglePassword() {
    const x = (document.getElementById('pwd') as HTMLInputElement);
    if (x.type === 'password') {
      x.type = 'text';
      this.eyeicon = 'fas fa-eye-slash';
    } else {
      x.type = 'password';
      this.eyeicon = 'fas fa-eye';
    }
  }
}
