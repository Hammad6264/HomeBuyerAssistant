import { Component } from '@angular/core';
import {CommonServices} from '../../../Shared/CommonService';
import {NgForm} from '@angular/forms';
import {AuthService} from '../../../Shared/AuthService';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.page.html',
  styleUrls: ['./forget.page.scss'],
})
export class ForgetPage {
  lng: string;
  lngE = '" English "';
  lngS = '" Esponol "';
  constructor(public commonService: CommonServices, private authService: AuthService) { }

  onForget(form: NgForm) {
    const email = form.value.email;
    if (email) {
      this.authService.resetPassword(email);
      form.reset();
    } else {
      this.commonService.presentAlert('Problem with email', 'Email is missing or not valid, please check!');
    }
  }

  ionViewWillEnter() {
    const myLanguage = localStorage.getItem('lng');
    this.lng = myLanguage;
  }
}
