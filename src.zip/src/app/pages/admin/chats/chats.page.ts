import { Component } from '@angular/core';
import {User} from '../../../models/user';
import {CommonServices} from '../../../Shared/CommonService';
import {UtilService} from '../../../services/util/util.service';
import {AngularFireDatabase} from '@angular/fire/database';
import {ChatsService} from '../../../services/chats/chats.service';
import {AuthService} from '../../../Shared/AuthService';
import {UserService} from '../../../Shared/userService';
import {map} from 'rxjs/operators';
import {LoadingController} from '@ionic/angular';

@Component({
  selector: 'app-chats',
  templateUrl: './chats.page.html',
  styleUrls: ['./chats.page.scss'],
})
export class ChatsPage {
  users: User[] = new Array<User>();
  chats: any;
  mySelf: any = {};
  constructor(
      private chatsService: ChatsService,
      private utilService: UtilService,
      private db: AngularFireDatabase,
      private auth: AuthService,
      private commonService: CommonServices,
      private userService: UserService,
      private loadCtrl: LoadingController
  ) {
    this.loadCtrl.create({
      message: 'Please wait while loading questions',
      spinner: 'lines'
    }).then(elementEl => {
      elementEl.present();
      this.mySelf = JSON.parse(this.userService.get());
      this.chatsService.getChats().snapshotChanges().pipe(
          map(changes => changes.map(c => ({
                key : c.payload.key, ...c.payload.val()
              }))
          )).subscribe(uids => {
        uids.map(uid => {
          console.log('user', uid);
          this.db.object(`/users/${uid.key}`).valueChanges().subscribe((user: User) => { user.key = uid.key;  this.users.push(user); elementEl.dismiss(); });
        });
        console.log('1', this.users);
      });
    });
  }
  openChat(key: string) {
    this.chatsService.chatter =  {
      uid : this.mySelf.id,
      interlocutorUID : key
    };
    this.commonService.navigate('/questions');
  }
}
