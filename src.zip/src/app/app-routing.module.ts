import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'languages', pathMatch: 'full' },
  {
    path: 'languages',
    loadChildren: () => import('./pages/user/languages/languages.module').then( m => m.LanguagesPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/auth/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./pages/auth/register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'forget',
    loadChildren: () => import('./pages/auth/forget/forget.module').then( m => m.ForgetPageModule)
  },
  {
    path: 'welcome',
    loadChildren: () => import('./pages/user/welcome/welcome.module').then( m => m.WelcomePageModule)
  },
  {
    path: 'step-guide',
    loadChildren: () => import('./pages/user/step-guide/step-guide.module').then( m => m.StepGuidePageModule)
  },
  {
    path: 'screens',
    loadChildren: () => import('./pages/user/screens/screens.module').then( m => m.ScreensPageModule)
  },
  {
    path: 'questions',
    loadChildren: () => import('./pages/user/questions/questions.module').then( m => m.QuestionsPageModule)
  },
  {
    path: 'chats',
    loadChildren: () => import('./pages/admin/chats/chats.module').then( m => m.ChatsPageModule)
  },
  {
    path: 'answers',
    loadChildren: () => import('./pages/admin/answers/answers.module').then( m => m.AnswersPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
