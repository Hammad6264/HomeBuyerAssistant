import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { AuthService } from '../auth/auth.service';
import { User } from 'src/app/models/user';
import * as firebase from 'firebase';

@Injectable({
    providedIn: 'root'
})
export class UserService {
    constructor(
      private db: AngularFireDatabase,
      private auth: AuthService,
  ) {}
    getUID(): string {
       const user = JSON.parse(this.auth.get());
       console.log(user);
       console.log('getCurrentUserUid', user.id);
       return user.id;
    }
    createUser(user: User): void {
        const userRef = this.db.object(`users/${this.getUID()}`);
        userRef.set({email: user.email, name: user.name});
    }
     getUser(): AngularFireObject<User> {
        return this.db.object(`/users/${this.getUID()}`);

    }
    getAllUsers(): AngularFireList<User> {
      return this.db.list(`/users`);
    }

  }

