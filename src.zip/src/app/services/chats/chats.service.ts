import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { UserService } from '../user/user.service';
import { Chatter } from 'src/app/models/chatter';

@Injectable({
    providedIn: 'root'
})
export class ChatsService {
  public chatter: Chatter;
  constructor(
      private db: AngularFireDatabase,
      private userService: UserService) {
        this.chatter = new Chatter();
     }
  getChats(): AngularFireList<any> {
   const uid: string = this.userService.getUID();
   console.log('getChats uid', uid);
   return  this.db.list(`/users/${uid}/chats`);
  }
  addChats(uid: string, interlocutorUID: string): void  {
   const endPoint: AngularFireObject<boolean> = this.db.object(`/users/${uid}/chats/${interlocutorUID}`);
   endPoint.set(true);
   const endPoint2: AngularFireObject<boolean> = this.db.object(`/users/${interlocutorUID}/chats/${uid}`);
   endPoint2.set(true);
  }
  getChatRef(uid: string, interlocutorUID: string): Promise<any> {
    console.log(uid, interlocutorUID);
    const firstRef =  this.db.object(`chats/${uid},${interlocutorUID}`);
    const promise = new Promise((resolve, reject) => {
      firstRef.snapshotChanges().subscribe(snpashot => {
        const a = snpashot.payload.exists();
        if (a) {
          resolve(`chats/${uid},${interlocutorUID}`);
        } else {
          const secondRef = this.db.object(`chats/${interlocutorUID},${uid}`);
          secondRef.snapshotChanges().subscribe(snpashot => {
            const b = snpashot.payload.exists();
            if (!b) {
              this.addChats(uid, interlocutorUID);
            }
          });
          resolve(`/chats/${interlocutorUID},${uid}`);
          }
        });
    });
    return promise;
 }
}
