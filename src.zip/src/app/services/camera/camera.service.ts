import { Injectable } from '@angular/core';
import { UserService } from '../user/user.service';
import { AngularFireDatabase } from '@angular/fire/database';

@Injectable({
    providedIn: 'root'
})
export class CameraService {

  constructor(private userSevice: UserService, private db: AngularFireDatabase) {

   }
}
