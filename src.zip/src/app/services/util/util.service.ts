import { Injectable } from '@angular/core';
import { AlertController, ToastController, LoadingController } from '@ionic/angular';

@Injectable({
    providedIn: 'root'
})
export class UtilService {
  constructor(
      private alertController: AlertController,
      private toastController: ToastController,
      private loadingController: LoadingController
  ) { }
  doToast(title: string, msg: string): void  {
     this.toastController.create({
      header: title,
      message: msg,
      position: 'top',
      duration: 3000,
      animated: true
    }).then(toast => toast.present()).catch(err => console.log('Toast Error :', err));
  }
  doLoading(msg: string): void {
    this.loadingController.create({
      message: msg,
      spinner: 'lines',
      animated: true,
      duration: 3000,
    }).then(loading => loading.present()).catch(err => console.log('Loading Error', err));
  }
  doAlert(title: string, msg: string, buttonText: string): void {
    this.alertController.create({
      header: title,
      message: msg,
      buttons: [buttonText]
    }).then(alert => alert.present()).catch(err => console.log('Alert Error', err));
  }
}
