import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { User } from 'src/app/models/user';
import {AlertController, LoadingController} from '@ionic/angular';
import * as firebase from 'firebase';
import {CommonServices} from '../../Shared/CommonService';
import {HttpClient} from '@angular/common/http';
import swal from 'sweetalert2';
import {first, map, switchMap, tap} from 'rxjs/operators';
import {of} from 'rxjs';
import {AngularFireDatabase} from '@angular/fire/database';
import {UserService} from '../../Shared/userService';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

  constructor(
      private afAuth: AngularFireAuth,
      private loadCtrl: LoadingController,
      private alertCtrl: AlertController,
      private commonService: CommonServices,
      private httpClient: HttpClient,
      private db: AngularFireDatabase,
      private userService: UserService
  ) {
      this.updateOnUser().subscribe();
      this.updateOnDisconnect().subscribe();
      this.updateOnAway();
  }
   public getAuth(): firebase.auth.Auth {
      return this.afAuth.auth;
   }
   public getCurrentUserUid(): string {
    const mySelf = JSON.parse(this.userService.get());
    return mySelf.id;
  }
   signinUser(email: string, password: string) {
        this.loadCtrl.create({
            message: 'Please wait...',
            spinner: 'lines'
        }).then((loadingEl) => {
            loadingEl.present();
            firebase.auth().signInWithEmailAndPassword(email, password)
                .then((response) => {
                    console.log(response);
                    if (response.user.emailVerified) {
                        loadingEl.dismiss();
                        this.commonService.navigate('/account');
                        this.alertCtrl.create({
                            header: 'Account Succesfully Logged In!',
                            message: 'Welcome back! you have been successfully logged in. Thanks!',
                            buttons: [{
                                text: 'Okay!',
                                role: 'cancel'
                            }]
                        }).then((getAlert) => {
                            getAlert.present();
                        });
                        return this.getUserFromDatabase(response.user.uid);
                    } else {
                        firebase.auth().currentUser.sendEmailVerification();
                        firebase.auth().signOut();
                        loadingEl.dismiss();
                        this.alertCtrl.create({
                            header: 'Email Not Verified!',
                            message: 'Your email is not verify yet. Please check your email and verify it!',
                            buttons: [{
                                text: 'Okay!',
                                handler: () => {
                                    this.commonService.navigate('/login');
                                }
                            }]
                        }).then((elementEl) => {
                            elementEl.present();
                        });
                    }
                }, (err) => {
                    loadingEl.dismiss();
                    this.alertCtrl.create({
                        header: 'Error in Logging Your Account!',
                        subHeader: err.code,
                        message: err.message,
                        buttons: [{
                            text: 'Okay!',
                            role: 'dismiss'
                        }]
                    }).then((elementEl) => {
                        elementEl.present();
                    });
                }).then((data) => {
                if (data) {
                    this.set(data);
                    console.log(data);
                } else {
                    console.log('Bad Luck!');
                }
            });
        });
    }
   set(userFromDatabase) {
        localStorage.setItem('user', JSON.stringify(userFromDatabase));
    }
   get() {
        return localStorage.getItem('user');
    }
   createAccount(userName: string, mobileNumber: number, gmail: string, pass: string, profile) {
        this.loadCtrl.create({
            message: 'Please wait...',
            spinner: 'lines'
        }).then((loadingEl) => {
            loadingEl.present();
            this.httpClient.post('http://apilayer.net/api/validate?access_key=' +
                'f7075d87dafe8ceb8182bdbce2a77e36&number=' + mobileNumber, '').subscribe(res => {
                if (res['valid']) {
                    firebase.auth().createUserWithEmailAndPassword(gmail, pass).then((userData) => {
                        console.log(userData);
                        const user = firebase.auth().currentUser;
                        user.sendEmailVerification();
                        firebase.database().ref('users/' + userData.user.uid).set({
                            name: userName,
                            phone: mobileNumber,
                            picture: profile,
                            email: gmail,
                            password: pass,
                            registerationDate: new Date().toString(),
                            id: firebase.auth().currentUser.uid,
                        }).then(() => {
                            firebase.auth().signOut();
                            loadingEl.dismiss();
                            this.alertCtrl.create({
                                header: 'Account Succesfully Created!',
                                // tslint:disable-next-line:max-line-length
                                message: 'Thanks for creating your account! your account has been successfully created. Please check your email to verify your account, and then please Login to proceed. Thanks!',
                                buttons: [{
                                    text: 'Okay!',
                                    handler: () => {
                                        alert('Please check your email to verify');
                                        this.commonService.navigate('/login');
                                    }
                                }]
                            }).then((elementEl) => {
                                elementEl.present();
                            });
                        });
                    }, (err) => {
                        loadingEl.dismiss();
                        this.alertCtrl.create({
                            header: err.code,
                            message: err.message,
                            buttons: [{
                                text: 'Okay!',
                                role: 'dismiss'
                            }]
                        }).then((elementEl) => {
                            elementEl.present();
                        });
                    });
                } else {
                    loadingEl.dismiss();
                    this.presentAlert('Check your number', 'Your number is not valid or incorrect', 'error');
                }
            });
        });
    }
   logout() {
        localStorage.clear();
        firebase.auth().signOut();
        this.commonService.navigate('/login');
    }
   getUserFromDatabase(uid) {
        const ref = firebase.database().ref('users/' + uid);
        this.set(uid);
        return ref.once('value').then(snapshot => snapshot.val());
    }
   presentAlert(heading, msg, font) {
      swal.fire({
            title: heading,
            text: msg,
            icon: font
        });
    }
   getPresence(uid: string) {
        return this.db.object(`status/${uid}`).valueChanges();
    }
   getUser() {
        return this.afAuth.authState.pipe(first()).toPromise();
    }
   async setPresence(status: string) {
        const user = await this.getUser();
        if (user) {
            return this.db.object(`status/${user.uid}`).update({ status, timestamp: this.timestamp });
        }
    }
   get timestamp() {
        return firebase.database.ServerValue.TIMESTAMP;
    }
   updateOnUser() {
        const connection = this.db.object('.info/connected').valueChanges().pipe(
            map(connected => connected ? 'online' : 'offline')
        );
        return this.afAuth.authState.pipe(
            switchMap(user =>  user ? connection : of('offline')),
            tap(status => this.setPresence(status))
        );
    }
   updateOnDisconnect() {
        return this.afAuth.authState.pipe(
            tap(user => {
                if (user) {
                    this.db.object(`status/${user.uid}`).query.ref.onDisconnect()
                        .update({
                            status: 'offline',
                            timestamp: this.timestamp
                        });
                }
            })
        );
    }
   updateOnAway() {
        document.onvisibilitychange = (e) => {
            if (document.visibilityState === 'hidden') {
                this.setPresence('away');
            } else {
                this.setPresence('online');
            }
        };
    }
}
