import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import {ShareModule} from './Shared/SharedModule';
import {AngularFireModule} from '@angular/fire';
import {AngularFireDatabaseModule} from '@angular/fire/database';
import {AngularFireAuthModule} from '@angular/fire/auth';

const config = {
  apiKey: 'AIzaSyAqVAWjNnSiXYKf6u_1udE_bd1FknocmFs',
  authDomain: 'home-buyer-assistant.firebaseapp.com',
  databaseURL: 'https://home-buyer-assistant.firebaseio.com',
  projectId: 'home-buyer-assistant',
  storageBucket: 'home-buyer-assistant.appspot.com',
  messagingSenderId: '159484156704',
  appId: '1:159484156704:web:2d8e49f0b935febf3d1545',
  measurementId: 'G-VETE29PBQ8'
};

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule,
    AngularFireModule.initializeApp(config),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    ShareModule,
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
