export  class Chat {
    from : string;
    type: string;
    message: string;
    to: string;
    picture: any;
}