export class User {
    key: string;
    email : string;
    password: string;
    picture: string;
    name : string;
}