export class Chatter {
    uid  : string;
    interlocutorUID : string
}