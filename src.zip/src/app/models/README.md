### models

This is folder contains all the **models** of the app.
